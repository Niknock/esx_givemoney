	fx_version 'cerulean'
	games { 'gta5' }
	author 'Niknock HD'
	description 'esx_givemoney'

	server_scripts {
		"server.lua"
}