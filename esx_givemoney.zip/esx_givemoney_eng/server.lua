	ESX = nil

	TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)

--Give Money--

RegisterCommand("givemoney", function(source, args, rawCommand)
	xPlayer = ESX.GetPlayerFromId(args[1])
	local xGroup = xPlayer.getGroup()

	if xGroup == "admin" then


		xPlayer.addMoney(args[2])
		TriggerClientEvent("esx:showNotification", source, "~g~You have given the player with the ID:"..args[1].." " ..args[2].."$")

	else

		TriggerClientEvent("esx:showNotification", source, "~r~You have no Permisson!")

	end

		if xPlayer == nil then

		TriggerClientEvent("esx:showNotification", source, "~r~ID"..args[1].."Have not been found!")
				
	end
end)


--Remove Money--


RegisterCommand("removemoney", function(source, args, rawCommand)
	xPlayer = ESX.GetPlayerFromId(args[1])
	local xGroup = xPlayer.getGroup()

	if xGroup == "admin" then

	--if xPlayer ~= nil then

		xPlayer.removeMoney(args[2])
		TriggerClientEvent("esx:showNotification", source, "~g~You have removed the player with the ID:"..args[1].." " ..args[2].."$")

	else

		TriggerClientEvent("esx:showNotification", source, "~r~You have no Permisson!")

	end

		if xPlayer == nil then

		TriggerClientEvent("esx:showNotification", source, "~r~ID"..args[1].."Have not been found!")
				
	end
end)
