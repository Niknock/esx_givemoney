	fx_version 'cerulean'
	games { 'gta5' }
	author 'Niknock HD'
	description 'Geld Command'

	server_scripts {
		"server.lua"
}