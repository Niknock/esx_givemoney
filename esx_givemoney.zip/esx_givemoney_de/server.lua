	ESX = nil

	TriggerEvent("esx:getSharedObject", function(obj) ESX = obj end)

--Geld Geben--

RegisterCommand("givemoney", function(source, args, rawCommand)
	xPlayer = ESX.GetPlayerFromId(args[1])
	local xGroup = xPlayer.getGroup()

	if xGroup == "admin" then


		xPlayer.addMoney(args[2])
		TriggerClientEvent("esx:showNotification", source, "~g~Du hast dem Spieler mit der ID:"..args[1].." " ..args[2].."$ gegeben")

	else

		TriggerClientEvent("esx:showNotification", source, "~r~Du hast keine Berechtigung!")

	end

		if xPlayer == nil then

		TriggerClientEvent("esx:showNotification", source, "~r~ID"..args[1].."wurde nicht gefunden!")
				
	end
end)


--Geld Entfernen--


RegisterCommand("removemoney", function(source, args, rawCommand)
	xPlayer = ESX.GetPlayerFromId(args[1])
	local xGroup = xPlayer.getGroup()

	if xGroup == "admin" then

	--if xPlayer ~= nil then

		xPlayer.removeMoney(args[2])
		TriggerClientEvent("esx:showNotification", source, "~g~Du hast dem Spieler mit der ID:"..args[1].." " ..args[2].."$ entfernt")

	else

		TriggerClientEvent("esx:showNotification", source, "~r~Du hast keine Berechtigung!")

	end

		if xPlayer == nil then

		TriggerClientEvent("esx:showNotification", source, "~r~ID"..args[1].."wurde nicht gefunden!")
				
	end
end)
